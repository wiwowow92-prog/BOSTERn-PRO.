# BOSTERn PRO v1.1

Native Android starter project for a black/red gaming dashboard.

## Features
- Installed launchable-app library and launch buttons (Android package visibility may limit which apps appear)
- Live available RAM estimate
- Android thermal status on API 29+
- Shortcuts to Android gaming-related settings
- Original supplied BOSTERn PRO logo
- Optional donation welcome screen with a visible X / skip action
- Donation/support section also shown in the lobby
- DANA number tap-to-copy, TikTok profile link, and WhatsApp chat link
- Android 8.0+ (API 26+) target

## Build APK
Open this folder in Android Studio (Hedgehog or newer), allow Gradle sync, then select **Build > Build Bundle(s) / APK(s) > Build APK(s)**. The debug APK is created at `app/build/outputs/apk/debug/app-debug.apk`.

## Important limitations
Android does not let ordinary third-party apps safely force CPU/GPU clocks, magically increase FPS, or universally clear other apps' memory. BOSTERn PRO reports available memory and device thermal status where Android exposes them, opens installed apps, and links to system settings. It does not claim fake performance gains.


## Donation details
- DANA: 087886431406 (tap to copy)
- TikTok: https://www.tiktok.com/@kanjjjutttt_
- WhatsApp: https://wa.me/6287886431406

Donations are optional; the X and skip button enter the lobby without donating. The brand marks in this build are simple in-app text/glyph treatments, not official vector logo files.
