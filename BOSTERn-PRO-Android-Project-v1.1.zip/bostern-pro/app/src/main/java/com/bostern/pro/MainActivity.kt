package com.bostern.pro

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.widget.*
import android.app.ActivityManager
import android.content.pm.PackageManager
import android.content.pm.ResolveInfo
import android.animation.ValueAnimator

class MainActivity : Activity() {
    private val red = Color.rgb(255, 35, 48)
    private val bg = Color.rgb(8, 9, 12)
    private val panel = Color.rgb(20, 22, 28)
    private lateinit var root: LinearLayout
    private lateinit var ramValue: TextView
    private lateinit var gameList: LinearLayout
    private lateinit var statusText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        window.decorView.systemUiVisibility = 0
        showDonationGate()
    }

    private fun buildUi() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            setPadding(dp(20), dp(18), dp(20), dp(24))
        }
        val scroll = ScrollView(this).apply { isFillViewport = true; addView(root) }
        setContentView(scroll)

        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val brand = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; layoutParams = LinearLayout.LayoutParams(0, -2, 1f) }
        brand.addView(label("BOSTERn PRO", 25f, red, true))
        brand.addView(label("MOBILE GAMING CONTROL", 10f, Color.LTGRAY, true))
        top.addView(brand)
        val live = label("● SYSTEM READY", 10f, Color.rgb(80, 235, 145), true)
        top.addView(live)
        root.addView(top)
        root.addView(space(18))

        val hero = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(18), dp(22), dp(18), dp(22))
            background = gradient(intArrayOf(Color.rgb(45, 8, 14), Color.rgb(18, 18, 24)), 22)
        }
        val logo = ImageView(this).apply {
            setImageResource(com.bostern.pro.R.drawable.bostern_logo)
            scaleType = ImageView.ScaleType.CENTER_CROP
            layoutParams = LinearLayout.LayoutParams(dp(132), dp(132))
            clipToOutline = true
            background = rounded(Color.BLACK, 24)
        }
        hero.addView(logo)
        hero.addView(space(12))
        hero.addView(label("READY FOR YOUR NEXT MATCH?", 14f, Color.WHITE, true))
        hero.addView(space(5))
        hero.addView(label("Launch your games. Monitor your device.", 11f, Color.LTGRAY, false))
        root.addView(hero)
        root.addView(space(18))

        root.addView(sectionTitle("DEVICE STATUS", "LIVE MONITOR"))
        val stats = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val ramCard = statCard("AVAILABLE RAM", "--", "Estimated free memory")
        ramValue = ramCard.second
        stats.addView(ramCard.first, LinearLayout.LayoutParams(0, dp(104), 1f))
        stats.addView(spaceView(10))
        val thermal = statCard("THERMAL", thermalLabel(), "Android system status")
        stats.addView(thermal.first, LinearLayout.LayoutParams(0, dp(104), 1f))
        root.addView(stats)
        root.addView(space(10))
        statusText = label("Monitoring device information…", 11f, Color.LTGRAY, false)
        root.addView(statusText)
        root.addView(space(20))

        root.addView(sectionTitle("QUICK ACTIONS", "SAFE CONTROLS"))
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        actions.addView(actionButton("GAME MODE", "Open gaming settings") { openGameSettings() }, LinearLayout.LayoutParams(0, dp(76), 1f))
        actions.addView(spaceView(10))
        actions.addView(actionButton("REFRESH", "Update device stats") { refreshStats(); loadGames() }, LinearLayout.LayoutParams(0, dp(76), 1f))
        root.addView(actions)
        root.addView(space(20))

        root.addView(sectionTitle("MY GAME LIBRARY", "INSTALLED LAUNCHABLE APPS"))
        gameList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(gameList)
        root.addView(space(18))
        addDonationPanel(root)
        root.addView(space(18))
        root.addView(label("BOSTERn PRO  •  VERSION 1.1", 10f, Color.GRAY, true).apply { gravity = Gravity.CENTER })
        root.addView(space(6))
        root.addView(label("No fake FPS boost. Android controls hardware performance.", 10f, Color.GRAY, false).apply { gravity = Gravity.CENTER })

        // Subtle animated accent sweep
        val pulse = ValueAnimator.ofInt(110, 255, 110).apply {
            duration = 2200; repeatCount = ValueAnimator.INFINITE; interpolator = DecelerateInterpolator()
            addUpdateListener { top.alpha = (it.animatedValue as Int) / 255f }
        }
        pulse.start()
    }

    // Optional support screen shown before the lobby. Closing it never blocks the app.
    private fun showDonationGate() {
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(22), dp(18), dp(22), dp(28))
            setBackgroundColor(bg)
        }
        val scroll = ScrollView(this).apply { isFillViewport = true; addView(page) }
        setContentView(scroll)

        val top = FrameLayout(this).apply { layoutParams = LinearLayout.LayoutParams(-1, dp(48)) }
        val skip = TextView(this).apply {
            text = "✕"
            textSize = 22f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            background = rounded(panel, 24)
            layoutParams = FrameLayout.LayoutParams(dp(44), dp(44), Gravity.END or Gravity.CENTER_VERTICAL)
            contentDescription = "Lewati donasi"
            setOnClickListener { enterLobby() }
        }
        top.addView(skip)
        page.addView(top)
        page.addView(space(12))

        val logo = ImageView(this).apply {
            setImageResource(com.bostern.pro.R.drawable.bostern_logo)
            scaleType = ImageView.ScaleType.CENTER_CROP
            layoutParams = LinearLayout.LayoutParams(dp(116), dp(116))
            background = rounded(Color.BLACK, 22)
            clipToOutline = true
        }
        page.addView(logo)
        page.addView(space(15))
        page.addView(label("SUPPORT THE DEVELOPER", 11f, red, true))
        page.addView(space(5))
        val heading = label("Bantu BOSTERn PRO terus berkembang", 20f, Color.WHITE, true).apply { gravity = Gravity.CENTER; textAlignment = View.TEXT_ALIGNMENT_CENTER }
        page.addView(heading)
        page.addView(space(8))
        page.addView(label("Donasi sepenuhnya sukarela. Kamu bisa langsung tekan ✕ untuk melewati halaman ini dan masuk ke aplikasi.", 12f, Color.LTGRAY, false).apply { gravity = Gravity.CENTER; textAlignment = View.TEXT_ALIGNMENT_CENTER })
        page.addView(space(22))

        page.addView(donationAction("DANA", "Kirim dukungan melalui DANA", "DANA", Color.rgb(0, 112, 235)) {
            val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
            clipboard.setPrimaryClip(android.content.ClipData.newPlainText("Nomor DANA BOSTERn PRO", "087886431406"))
            Toast.makeText(this, "Nomor DANA disalin: 087886431406", Toast.LENGTH_LONG).show()
        })
        page.addView(space(10))
        page.addView(donationAction("TikTok", "Ikuti update BOSTERn PRO", "♪", Color.BLACK) {
            openExternal("https://www.tiktok.com/@kanjjjutttt_")
        })
        page.addView(space(10))
        page.addView(donationAction("WhatsApp", "Hubungi developer", "☎", Color.rgb(20, 170, 90)) {
            openExternal("https://wa.me/6287886431406")
        })
        page.addView(space(18))
        val skipText = TextView(this).apply {
            text = "LANJUT TANPA DONASI  →"
            textSize = 12f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            background = rounded(red, 14)
            setPadding(dp(18), dp(15), dp(18), dp(15))
            setOnClickListener { enterLobby() }
        }
        page.addView(skipText, LinearLayout.LayoutParams(-1, -2))
        page.addView(space(12))
        page.addView(label("BOSTERn PRO • OPTIONAL SUPPORT", 9f, Color.GRAY, true).apply { gravity = Gravity.CENTER })

        // Soft red glow pulse on the main heading.
        val pulse = ValueAnimator.ofFloat(0.72f, 1f, 0.72f).apply {
            duration = 2100; repeatCount = ValueAnimator.INFINITE
            addUpdateListener { heading.alpha = it.animatedValue as Float }
        }
        pulse.start()
    }

    private fun enterLobby() {
        buildUi()
        refreshStats()
        loadGames()
    }

    private fun addDonationPanel(parent: LinearLayout) {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(15), dp(15), dp(15), dp(15))
            background = gradient(intArrayOf(Color.rgb(38, 9, 15), panel), 18)
        }
        card.addView(label("SUPPORT BOSTERn PRO", 12f, red, true))
        card.addView(space(5))
        card.addView(label("Mau dukung pengembangan aplikasi? Donasi tidak wajib.", 10f, Color.LTGRAY, false))
        card.addView(space(12))
        card.addView(donationAction("DANA", "087886431406 • Ketuk untuk salin nomor", "DANA", Color.rgb(0, 112, 235)) {
            val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
            clipboard.setPrimaryClip(android.content.ClipData.newPlainText("Nomor DANA BOSTERn PRO", "087886431406"))
            Toast.makeText(this, "Nomor DANA disalin", Toast.LENGTH_SHORT).show()
        })
        card.addView(space(8))
        card.addView(donationAction("TikTok", "@kanjjjutttt_", "♪", Color.BLACK) {
            openExternal("https://www.tiktok.com/@kanjjjutttt_")
        })
        card.addView(space(8))
        card.addView(donationAction("WhatsApp", "087886431406", "☎", Color.rgb(20, 170, 90)) {
            openExternal("https://wa.me/6287886431406")
        })
        parent.addView(card)
    }

    private fun donationAction(title: String, subtitle: String, mark: String, markColor: Int, action: () -> Unit): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(11), dp(12), dp(11))
            background = rounded(panel, 14)
            isClickable = true
            isFocusable = true
            setOnClickListener { action() }
        }
        val icon = TextView(this).apply {
            text = mark
            textSize = if (mark == "DANA") 14f else 25f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setTextColor(if (mark == "DANA") Color.rgb(0, 112, 235) else Color.WHITE)
            background = rounded(if (mark == "DANA") Color.WHITE else markColor, 11)
            if (title == "TikTok") setShadowLayer(dp(3).toFloat(), dp(2).toFloat(), dp(1).toFloat(), Color.rgb(0, 220, 230))
            layoutParams = LinearLayout.LayoutParams(dp(48), dp(48))
        }
        row.addView(icon)
        val texts = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), 0, 0, 0)
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
            addView(label(title, 13f, Color.WHITE, true))
            addView(label(subtitle, 10f, Color.LTGRAY, false))
        }
        row.addView(texts)
        row.addView(label("›", 25f, red, true))
        return row
    }

    private fun openExternal(url: String) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        } catch (_: Exception) {
            Toast.makeText(this, "Aplikasi atau tautan tidak tersedia", Toast.LENGTH_SHORT).show()
        }
    }

    private fun sectionTitle(title: String, tag: String): View {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        row.addView(label(title, 13f, Color.WHITE, true), LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(label(tag, 9f, red, true))
        return row
    }

    private fun statCard(title: String, value: String, note: String): Pair<View, TextView> {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(13), dp(12), dp(13), dp(10)); background = rounded(panel, 16)
        }
        card.addView(label(title, 9f, Color.LTGRAY, true))
        val v = label(value, 24f, Color.WHITE, true)
        card.addView(v)
        card.addView(label(note, 9f, Color.GRAY, false))
        return Pair(card, v)
    }

    private fun actionButton(title: String, sub: String, action: () -> Unit): View {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(12), dp(10), dp(8), dp(10)); background = rounded(panel, 15)
            addView(label(title, 12f, red, true)); addView(label(sub, 9f, Color.LTGRAY, false)); isClickable = true; isFocusable = true
            setOnClickListener { action() }
        }
    }

    private fun loadGames() {
        gameList.removeAllViews()
        val intent = Intent(Intent.ACTION_MAIN, null).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps: List<ResolveInfo> = packageManager.queryIntentActivities(intent, PackageManager.MATCH_ALL)
            .filter { it.activityInfo.packageName != packageName }
            .sortedBy { it.loadLabel(packageManager).toString().lowercase() }
        if (apps.isEmpty()) {
            gameList.addView(label("No launchable apps found.", 12f, Color.LTGRAY, false))
            return
        }
        apps.forEach { info ->
            val item = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(12), dp(9), dp(12), dp(9)); background = rounded(panel, 13)
                val icon = ImageView(this@MainActivity).apply { setImageDrawable(info.loadIcon(packageManager)); layoutParams = LinearLayout.LayoutParams(dp(38), dp(38)) }
                addView(icon)
                val textCol = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(10), 0, 0, 0); layoutParams = LinearLayout.LayoutParams(0, -2, 1f) }
                textCol.addView(label(info.loadLabel(packageManager).toString(), 13f, Color.WHITE, true))
                textCol.addView(label("Tap LAUNCH to open", 9f, Color.GRAY, false))
                addView(textCol)
                val launch = TextView(this@MainActivity).apply {
                    text = "LAUNCH"; textSize = 10f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
                    setPadding(dp(12), dp(8), dp(12), dp(8)); background = rounded(red, 9)
                }
                addView(launch)
                setOnClickListener { launchApp(info.activityInfo.packageName) }
                launch.setOnClickListener { launchApp(info.activityInfo.packageName) }
            }
            val lp = LinearLayout.LayoutParams(-1, -2); lp.bottomMargin = dp(8)
            gameList.addView(item, lp)
        }
    }

    private fun launchApp(pkg: String) {
        val launch = packageManager.getLaunchIntentForPackage(pkg)
        if (launch != null) startActivity(launch) else Toast.makeText(this, "App tidak dapat dibuka", Toast.LENGTH_SHORT).show()
    }

    private fun refreshStats() {
        val manager = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val memory = ActivityManager.MemoryInfo()
        manager.getMemoryInfo(memory)
        val freeGb = memory.availMem / (1024.0 * 1024.0 * 1024.0)
        val totalGb = memory.totalMem / (1024.0 * 1024.0 * 1024.0)
        ramValue.text = String.format("%.1f GB", freeGb)
        statusText.text = String.format("Available %.1f GB / %.1f GB total RAM • Updated just now", freeGb, totalGb)
    }

    private fun thermalLabel(): String {
        if (android.os.Build.VERSION.SDK_INT < 29) return "N/A"
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        return when (pm.currentThermalStatus) {
            PowerManager.THERMAL_STATUS_NONE -> "NORMAL"
            PowerManager.THERMAL_STATUS_LIGHT -> "LIGHT"
            PowerManager.THERMAL_STATUS_MODERATE -> "MODERATE"
            PowerManager.THERMAL_STATUS_SEVERE -> "SEVERE"
            PowerManager.THERMAL_STATUS_CRITICAL -> "CRITICAL"
            PowerManager.THERMAL_STATUS_EMERGENCY -> "EMERGENCY"
            else -> "UNKNOWN"
        }
    }

    private fun openGameSettings() {
        val candidates = listOf(
            Intent(Settings.ACTION_DISPLAY_SETTINGS),
            Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS),
            Intent(Settings.ACTION_SETTINGS)
        )
        val chosen = candidates.firstOrNull { it.resolveActivity(packageManager) != null } ?: Intent(Settings.ACTION_SETTINGS)
        startActivity(chosen)
    }

    private fun label(text: String, size: Float, color: Int, bold: Boolean): TextView = TextView(this).apply {
        this.text = text; textSize = size; setTextColor(color); if (bold) typeface = Typeface.DEFAULT_BOLD
    }
    private fun space(h: Int): View = View(this).apply { layoutParams = LinearLayout.LayoutParams(1, dp(h)) }
    private fun spaceView(w: Int): View = View(this).apply { layoutParams = LinearLayout.LayoutParams(dp(w), 1) }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat() }
    private fun gradient(colors: IntArray, radius: Int) = GradientDrawable(GradientDrawable.Orientation.TL_BR, colors).apply { cornerRadius = dp(radius).toFloat(); setStroke(dp(1), Color.rgb(100, 22, 30)) }
}
